insert into RESERVACENTRAL VALUES(reserva_sequence.nextval,5000000,2000000,2000000,2,4);
insert into TESORO VALUES(tesoro_sequence.nextval,40000,20000,10000,1);
insert into TESORO VALUES(tesoro_sequence.nextval,40000,20000,10000,1);
insert into TESORO VALUES(tesoro_sequence.nextval,40000,20000,10000,1);
insert into TESORO VALUES(tesoro_sequence.nextval,40000,20000,10000,1);
insert into TESORO VALUES(tesoro_sequence.nextval,40000,20000,10000,1);
insert into TESORO VALUES(tesoro_sequence.nextval,40000,20000,10000,1);
insert into TESORO VALUES(tesoro_sequence.nextval,40000,20000,10000,1);
insert into TESORO VALUES(tesoro_sequence.nextval,40000,20000,10000,1);
insert into TESORO VALUES(tesoro_sequence.nextval,40000,20000,10000,1);
insert into TESORO VALUES(tesoro_sequence.nextval,40000,20000,10000,1);
insert into TESORO VALUES(tesoro_sequence.nextval,40000,20000,10000,1);
insert into TESORO VALUES(tesoro_sequence.nextval,40000,20000,10000,1);
insert into Reino VALUES(reino_sequence.nextval,'ACUARIO','www','ENERO',0,0,0,0,0,0,0,0,0,1,1,0);
insert into Reino VALUES(reino_sequence.nextval,'ARIES','www','MARZO',0,0,0,0,0,0,0,0,0,2,1,0);
insert into Reino VALUES(reino_sequence.nextval,'CANCER','www','JUNIO',0,0,0,0,0,0,0,0,0,3,1,0);
insert into Reino VALUES(reino_sequence.nextval,'CAPRICORNIO','www','DICIEMBRE',0,0,0,0,0,0,0,0,0,4,1,0);
insert into Reino VALUES(reino_sequence.nextval,'ESCORPION','www','OCTUBRE',0,0,0,0,0,0,0,0,0,5,1,0);
insert into Reino VALUES(reino_sequence.nextval,'GEMINIS','www','MAYO',0,0,0,0,0,0,0,0,0,6,1,0);
insert into Reino VALUES(reino_sequence.nextval,'LEO','www','JULIO',0,0,0,0,0,0,0,0,0,7,1,0);
insert into Reino VALUES(reino_sequence.nextval,'LIBRA','www','SEPTIEMBRE',0,0,0,0,0,0,0,0,0,8,1,0);
insert into Reino VALUES(reino_sequence.nextval,'PISCIS','www','FEBRERO',0,0,0,0,0,0,0,0,0,9,01,0);
insert into Reino VALUES(reino_sequence.nextval,'SAGITARIO','www','NOVIEMBRE',0,0,0,0,0,0,0,0,0,10,1,0);
insert into Reino VALUES(reino_sequence.nextval,'TAURO','www','ABRIL',0,0,0,0,0,0,0,0,0,11,1,0);
insert into Reino VALUES(reino_sequence.nextval,'VIRGO','www','AGOSTO',0,0,0,0,0,0,0,0,0,12,1,0);

insert into tropas VALUES(tropas_sequence.nextval,1,'Arqueras',20,100,40,2,20);
insert into tropas VALUES(tropas_sequence.nextval,2,'Piqueros',25,70,60,3,30);
insert into tropas VALUES(tropas_sequence.nextval,3,'Caballeros',100,20,30,5,50);
insert into tropas VALUES(tropas_sequence.nextval,4,'Magos',50,50,50,1,40);

insert into defensas VALUES(defensa_sequence.nextval,1,'Canones',1000,500,2000,450,20);
insert into defensas VALUES(defensa_sequence.nextval,2,'Torres',2000,1000,800,650,15);

commit;